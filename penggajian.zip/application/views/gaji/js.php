<script>
	$(document).ready(function() {
	    $('.select2').select2();
	    $( "#datepicker" ).datepicker({
			dateFormat: "yy-mm-dd",
			changeYear: true,
			changeMonth: true
		});
	});
</script>