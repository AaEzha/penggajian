<script>
	$(document).ready(function() {
		$( "#datepicker, #datepicker2" ).datepicker({
			dateFormat: "yy-mm-dd",
			changeYear: true,
			changeMonth: true
		});
	});
</script>